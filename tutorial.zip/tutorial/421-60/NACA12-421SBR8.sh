#!/bin/sh
#SBATCH -D /s/ls4/users/kbkoshelev/iceFoam/tutorials/421-60
#SBATCH -n 12
#SBATCH --exclusive
#SBATCH -o %j.out
#SBATCH -e %j.err
#SBATCH -t 72:00:00
#SBATCH -p hpc4-3d

module load openmpi/1.8
./AllrunParallel

